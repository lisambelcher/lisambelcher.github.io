<template>
  <ProductCard />
</template>

<script>
export default {
  name: 'Products'
}
</script>
