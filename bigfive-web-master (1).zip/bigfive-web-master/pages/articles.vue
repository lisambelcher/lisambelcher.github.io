<template>
  <div>
    <h1>Articles</h1>
    Under construction ...
  </div>
</template>

<script>
</script>
