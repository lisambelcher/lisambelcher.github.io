import Vue from 'vue'
import VueConfetti from 'vue-confetti'

Vue.use(VueConfetti)
