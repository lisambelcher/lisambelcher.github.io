module.exports = async (req, res) => {
  res.json({ ping: 'pong' })
}
